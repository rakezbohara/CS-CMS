<html>
<head>

</head>
<body>
    @lang('welcome.menu1')
</body>
</html>